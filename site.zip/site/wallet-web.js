//blockchain identity

function Wallet() {
	
	this.address = null;
	private : this.privKey = null;
}

function ECPointCompress( x, y )
{
    const out = new Uint8Array( x.length + 1 );

    out[0] = 2 + ( y[ y.length-1 ] & 1 );
    out.set( x, 1 );

    return out;
}
Wallet.prototype.generateKeyPair = function () {

	const privateKeyBuf = window.crypto.getRandomValues(new Uint8Array(32));
	const privKey = Secp256k1.uint256(privateKeyBuf, 16);
	
	const publicKey = Secp256k1.generatePublicKeyFromPrivateKeyData(privKey);
	const pubX = Secp256k1.uint256(publicKey.x, 16)
        const pubY = Secp256k1.uint256(publicKey.y, 16)
	const pub = ECPointCompress(publicKey.x, publicKey.y);
	this.address = bs58.encode(pub);

	this.privKey = privKey.toString('hex');
	
	
};

Wallet.prototype.Hash = function(data) {

	const digest = Secp256k1.uint256(data, 16);
	return digest;
};

Wallet.prototype.signHash = function(hash) {

	const sig = Secp256k1.ecsign(this.privKey, hash);
	return sig;
};

Wallet.prototype.verifySignature = function(address, sig, hash) {

	const publicKey = bs58.decode(address);
    	const pubX = Secp256k1.uint256(publicKey.x, 16);
	const pubY = Secp256k1.uint256(publicKey.y, 16);
	
	const sigR = Secp256k1.uint256(sig.r,16);
 	const sigS = Secp256k1.uint256(sig.s,16);
	const isValidSig = Secp256k1.ecverify(pubX, pubY, sigR, sigS, hash);
	return isValidSig;
};

Wallet.prototype.getAddress = function() {

    return this.address;
};
