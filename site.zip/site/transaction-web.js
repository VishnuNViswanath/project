function calculateHash (inputs, outputs, wallet) {
    return wallet.Hash(JSON.stringify(inputs, outputs)).toString();
}


function createNewTransaction(hash, signature, inputs, outputs) {

    const newTransaction = {
        //validator:validatoraddress,
        //amount
        //transactionId: uuid().split('-').join('')

        idHash: hash,
        timestamp: Date.now(),
        signature: signature,
        inputs: inputs,
        outputs: outputs
    };
    return newTransaction;
};


function addTransactionToPendingTransactions(transactionObj, block) {
    block.pendingTransactions.push(transactionObj);
    return block.getLastBlock()['index'] + 1;
};


function getTransaction(transactionId, block) {
    let correctTransaction = null;
    let correctBlock = null;

    block.chain.forEach(block => {
        block.transactions.forEach(transaction => {
            if (transaction.idHash === transactionId) {
                correctTransaction = transaction;
                correctBlock = block;
            };
        });
    });

    return {
        transaction: correctTransaction,
        block: correctBlock
    };
};


function getAddressData(address, block, index) {

    let addressBlock;
  //  block.chain.forEach(block => {
  //      block.transactions.forEach(transaction => {
    if(block.chain[index]) addressBlock = block.chain[index];

    if(addressBlock.transaction.outputs["optaddress"] === address) {
                const addressTransactions = transaction;
    };
  //      });
  //  });
/*
    let balance = 0;
    addressTransactions.forEach(transaction => {
        if (transaction.recipient === address) balance += transaction.amount;
        else if (transaction.sender === address) balance -= transaction.amount;
    });
*/
    return addressBlock;
        //addressBalance: balance
};
